// main.c
#include <stdio.h>
#include <string.h> // Include this for strcmp and other string functions
#include "grocery_store.h"

int main() {
    struct Customer customer;
    struct LoginInfo loginInfo = {"admin", "password"};
    int quantities[NUM_ITEMS] = {0};
    int choice, quantity;

    if (!login(&loginInfo)) {
        printf("Login failed.\n");
        return 1;
    }

    getCustomerDetails(&customer);

    displayMenu();

    printf("\nEnter the item name and quantity in units (0 to finish):\n");
    char itemName[50];
    while (1) {
        printf("Item name: ");
        scanf("%s", itemName);
        if (strcmp(itemName, "0") == 0)
            break;
        printf("Quantity in units: ");
        scanf("%d", &quantity);
        if (quantity < 0) {
            printf("Invalid quantity. Please enter a non-negative value.\n");
            continue;
        }
        int index = matchItemName(itemName);
        if (index == -1) {
            printf("Item not found. Please enter a valid item name.\n");
            continue;
        }
        quantities[index] += quantity;
    }

    printf("\nCustomer Name: %s\nAddress: %s\nPhone Number: %s\nItems purchased:\n", customer.name, customer.address, customer.phone);
    for (int i = 0; i < NUM_ITEMS; ++i) {
        if (quantities[i] > 0) {
            printf("- %d units of %s\n", quantities[i], GroceryItemNames[i]);
        }
    }

    // Save to file
    saveToFile(&customer, quantities);

    // Search for a customer by name (for demonstration purposes, search for the current customer)
    printf("\nSearching for customer data...\n");
    searchCustomerData(customer.name);

    return 0;
}

